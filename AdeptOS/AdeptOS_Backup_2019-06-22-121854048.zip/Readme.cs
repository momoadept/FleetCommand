﻿/*
 *   R e a d m e
 *   -----------
 * 
 *   This is the test empty deployment of AdeptOS
 * 
 */