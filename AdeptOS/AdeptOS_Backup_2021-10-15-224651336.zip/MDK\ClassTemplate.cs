﻿namespace IngameScript
{
    partial class Program
    {
        public class ClassTemplate
        {

        }
    }
}
